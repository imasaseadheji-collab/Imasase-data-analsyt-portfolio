# Portfolio Direction: Imasase Adheji

## Three stylistic approaches

### Theme Name: Editorial Intelligence
Very Brief Intro: A warm, print-inspired portfolio that treats analysis like editorial storytelling: confident headlines, considered whitespace, and small annotations that make the work feel authored.
Probability: 0.07

### Theme Name: Signal Room
Very Brief Intro: A dark, instrument-panel direction with electric chart colors and a focused analyst-at-work atmosphere. It makes the portfolio feel technical, nocturnal, and systems-minded.
Probability: 0.04

### Theme Name: Field Notes
Very Brief Intro: A tactile research notebook aesthetic using paper tones, ink-like rules, and restrained blue accents. It frames Imasase as a curious investigator who turns messy evidence into practical decisions.
Probability: 0.08

## Chosen approach: Editorial Intelligence

### Design Movement
Contemporary editorial design with Swiss-inspired structure, softened by the warmth of a printed annual report and the precision of a data brief.

### Core Principles
1. **Evidence before decoration.** Every visual motif should support clarity, hierarchy, or credibility.
2. **Asymmetric rhythm.** Use a strong left rail, offset cards, and editorial columns rather than a generic centered marketing grid.
3. **Warm precision.** Pair an ink-dark foundation with parchment surfaces and a singular chartreuse signal color.
4. **Work as proof.** Project cards should read like concise case-study excerpts, not generic service tiles.

### Color Philosophy
The palette uses near-black ink for trust and focus, a warm mineral paper tone for approachability, and a sharp chartreuse signal for moments that need attention—like a highlighted metric or a selected filter. The goal is to feel analytical without becoming sterile or overly corporate.

### Layout Paradigm
The homepage opens with a split editorial spread: a narrow identity rail at left and a large narrative field at right. Sections then alternate between dense evidence rows and generous breathing room. The project case study gets the largest visual weight because it is the proof of ability.

### Signature Elements
1. A vertical identity rail with a small square monogram mark.
2. Fine ruled lines and “brief” labels that echo a research memo.
3. Chartreuse metric callouts and tiny status pills used sparingly.

### Interaction Philosophy
Interactions should feel like examining a report: the user gets clear feedback, focused hover states, and intentional movement. Links should underline or shift in color; project cards should lift by only a few pixels; no decorative motion should compete with the content.

### Animation
Use short 180–240ms transitions with a strong ease-out. Reveal the identity rail first, then cascade the hero copy, then the proof metrics. Project cards can translate upward 4px on hover and expose an arrow. Respect reduced-motion preferences and keep all interaction motion transform/opacity based.

### Typography System
Use **DM Serif Display** for major editorial headlines and **Manrope** for interface text, metadata, body copy, and metrics. Headlines are large but compact, with italic emphasis for “evidence” moments. Labels use uppercase Manrope at 0.12em tracking. Body copy stays between 16–18px with generous line height.

### Brand Essence
Imasase Adheji helps teams move from messy data to confident decisions through clear analysis and practical dashboards. Personality: **curious, precise, grounded**.

### Brand Voice
Headlines are direct, specific, and slightly editorial. CTAs sound like invitations to inspect the work rather than sales slogans.

Example lines:
- “I turn the noise into a next move.”
- “Read the analysis behind the dashboard.”

### Wordmark & Logo
A compact monogram built from two offset “A” forms: one solid ink shape and one chartreuse cut-out, suggesting a signal extracted from a larger dataset. The mark should work as a square favicon and as a small identity stamp in the rail.

### Signature Brand Color
**Signal Chartreuse — #C7F36B.** It is bright enough to feel ownable and functional, while still sitting naturally beside ink, parchment, and muted blue-gray data tones.

## Style Decisions

- Signal Chartreuse #C7F36B functions as a precision marker for metrics, status, selected words, and the final contact climax—not as a general-purpose background across the site.
- Portfolio imagery should read as analytical evidence from Imasase’s desk, prioritising dashboards, annotated reports, data tables, charts, and working artifacts over generic technology imagery.
- Every major section belongs to one authored research brief and should carry section numbers, ruled lines, memo labels, or concise evidence-led copy.
- The offset A monogram and analyst-stamp language should recur with more confidence so the identity is memorable beyond the typography.
