import {
  ArrowDown,
  ArrowUpRight,
  Github,
  Linkedin,
  Menu,
  X,
} from "lucide-react";
import { useState } from "react";

const textureImage = "/manus-storage/imasase-research-texture_5270d440.jpg";
const monogram = "/manus-storage/imasase-monogram_c1f17917.png";
const dashboardScreens = [
  {
    title: "Executive Summary",
    label: "01 / OVERVIEW",
    src: "/manus-storage/executive-summary_6853a379.png",
    alt: "Power BI executive summary showing e-commerce operations KPIs and monthly trends",
  },
  {
    title: "Delivery Performance",
    label: "02 / OPERATIONS",
    src: "/manus-storage/delivery-performance_6ebc2cd3.png",
    alt: "Power BI delivery performance dashboard showing late deliveries by state",
  },
  {
    title: "Customer Experience",
    label: "03 / EXPERIENCE",
    src: "/manus-storage/customer-experience_aef29b7e.png",
    alt: "Power BI customer experience dashboard comparing review scores and delivery performance",
  },
  {
    title: "Data Quality",
    label: "04 / TRUST",
    src: "/manus-storage/data-quality_690404b8.png",
    alt: "Power BI data quality dashboard showing completeness and uniqueness checks",
  },
];

const navItems = [
  { label: "About", href: "#about" },
  { label: "Projects", href: "#projects" },
];

function SectionLabel({ number, children }: { number: string; children: React.ReactNode }) {
  return (
    <div className="section-label">
      <span>{number}</span>
      <span>{children}</span>
    </div>
  );
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="site-shell">
      <header className="site-header">
        <a className="portfolio-title" href="#top">Imasase's Portfolio</a>
        <nav className={`main-nav ${menuOpen ? "is-open" : ""}`} aria-label="Primary navigation">
          {navItems.map((item) => (
            <a key={item.href} href={item.href} onClick={() => setMenuOpen(false)}>{item.label}</a>
          ))}
          <a className="nav-contact" href="mailto:imasase176@gmail.com" onClick={() => setMenuOpen(false)}>Let’s talk <ArrowUpRight size={15} /></a>
        </nav>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? "Close menu" : "Open menu"} aria-expanded={menuOpen}>
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </header>

      <main id="top">
        <section className="hero-section">
          <div className="hero-rail">
            <span className="rail-kicker">DATA ANALYST / 001</span>
            <span className="rail-line" />
            <span className="rail-year">2026</span>
          </div>
          <div className="hero-copy">
            <p className="eyebrow">Portfolio · Analysis · Decisions</p>
            <div className="profile-placeholder" aria-label="Profile photo placeholder" />
            <div className="hero-bottom">
              <p className="hero-intro">I’m Imasase Adheji, a data analyst who turns complex data into clear insights and practical business decisions using Excel, SQL, and Power BI.</p>
              <a className="text-link" href="#projects">Explore projects <ArrowDown size={16} /></a>
            </div>
          </div>
          <div className="hero-visual hero-visual-card">
            <div className="hero-visual-grid" />
            <div className="hero-card-content">
              <span className="hero-card-kicker">ANALYST  PORTFOLIO</span>
              <strong>Questions<br /><em>into evidence.</em></strong>
              <span className="hero-card-rule" />
              <span className="hero-card-note">Excel · SQL · Power BI<br />Business analysis in practice</span>
            </div>
            <div className="hero-visual-caption"><span>FIELD NOTE 01</span><span></span></div>
          </div>
        </section>

        <section className="signal-strip" aria-label="Profile summary">
          <div className="signal-item"><span className="signal-dot" />Currently building a portfolio of practical analysis</div>
          <div className="signal-item signal-right">Open to analyst opportunities <ArrowUpRight size={16} /></div>
        </section>

        <section className="about-section section-pad" id="about">
          <div className="about-image" style={{ backgroundImage: `url(${textureImage})` }}>
          </div>
          <div className="about-copy">
            <SectionLabel number="01">About me</SectionLabel>
            <p>I’m developing my career at the intersection of data, technology, and practical business decisions. I like the part of analysis where a vague question becomes a clear metric, a messy table becomes a trustworthy model, and a dashboard becomes an action someone can take.</p>
            <p>My current focus is building a portfolio that demonstrates the full workflow: understanding the business, validating the data, analysing the pattern, and communicating the recommendation.</p>
            <div className="about-signoff"><span>— Imasase</span><span className="availability"><span className="signal-dot" />Available for opportunities</span></div>
          </div>
        </section>

        <section className="work-section section-pad" id="projects">
          <div className="section-head">
            <SectionLabel number="02">Projects</SectionLabel>
            <p className="section-note">A growing collection of practical analyses, built from business question to recommendation.</p>
          </div>
          <p className="projects-note">This is a portfolio of data projects—not an Olist-only website. Olist is the first featured case study; future Excel, SQL, and Power BI projects can be added here as separate project cards.</p>
          <article className="feature-project">
            <div className="project-visual project-summary-visual">
              <span className="project-summary-kicker">FEATURED PROJECT / 01</span>
              <strong>10k</strong>
              <span className="project-summary-label">orders explored</span>
              <span className="project-summary-line" />
              <span className="project-summary-note">Olist<br />e-commerce operations</span>
              <span className="project-number">01 / 01</span>
            </div>
            <div className="project-info">
              <div className="project-meta"><span>E-COMMERCE OPERATIONS</span><span>SQL · EXCEL · POWER BI</span></div>
              <h2>Finding the friction<br /><em>behind late delivery.</em></h2>
              <p className="project-description">A practical investigation into 10,000 orders from the Olist e-commerce dataset. The question: where is delivery performance breaking down, and what should the business investigate first?</p>
              <div className="project-metrics">
                <div><strong>10k</strong><span>orders explored</span></div>
                <div><strong>12.4%</strong><span>late delivered orders</span></div>
                <div><strong>3.96</strong><span>average review score</span></div>
              </div>
              <a className="outline-link" href="#dashboard-gallery">View the dashboard <ArrowUpRight size={17} /></a>
            </div>
          </article>
          <div className="case-study-intro">
            <div>
              <span className="case-study-kicker">CASE STUDY / FROM QUESTION TO ACTION</span>
              <h3>Turning delivery friction into an operational brief.</h3>
            </div>
            <div className="case-study-copy">
              <p>Using a 10,000-order practice subset of the Olist Brazilian e-commerce dataset, I investigated where late delivery was concentrated, how it related to customer reviews, and which operational actions deserved attention first.</p>
              <p>The workflow combined Excel for rapid profiling, SQL for repeatable KPI analysis and safe multi-table joins, and Power BI for a four-page manager-facing dashboard.</p>
            </div>
          </div>
          <div className="case-study-findings">
            <div><strong>RJ</strong><span>332 late deliveries<br />highest absolute volume</span></div>
            <div><strong>CE</strong><span>25.4% late rate<br />highest among 100+ delivered orders</span></div>
            <div><strong>2.5 vs 4.2</strong><span>late vs on-time<br />average review score</span></div>
            <div><strong>99%</strong><span>review coverage<br />of delivered orders</span></div>
          </div>
          <div className="dashboard-gallery" id="dashboard-gallery">
            <div className="gallery-head">
              <div>
                <SectionLabel number="01">One project · four views</SectionLabel>
                <h3 className="gallery-title">Olist dashboard walkthrough</h3>
              </div>
              <p>These four screenshots are not separate projects. Together, they form one Power BI case study: overview, delivery performance, customer impact, and data quality.</p>
            </div>
            <div className="gallery-grid">
              {dashboardScreens.map((screen) => (
                <figure className="dashboard-shot" key={screen.title}>
                  <div className="dashboard-shot-frame">
                    <img src={screen.src} alt={screen.alt} loading="lazy" />
                  </div>
                  <figcaption><span>{screen.label}</span><strong>{screen.title}</strong></figcaption>
                </figure>
              ))}
            </div>
          </div>
          <div className="case-study-recommendation">
            <div className="recommendation-label">RECOMMENDATION</div>
            <p>Prioritise RJ because it contributes the largest number of late deliveries, while investigating CE as the highest late-rate state among meaningful-volume segments. Review seller dispatch time, carrier handoffs, delivery distance, and promised-date accuracy, then monitor late rate, late-order volume, delivery days, and review score weekly.</p>
          </div>
        </section>

        <section className="contact-section section-pad" id="contact">
          <div className="contact-rail"><span>03</span><span>Contact brief</span><span className="contact-rail-line" /></div>
          <div className="contact-main">
            <p className="eyebrow">Final note / open invitation</p>
            <p className="contact-question">Have a question, opportunity, or data problem?</p>
            <h2>Let’s<br /><em>connect.</em></h2>
            <a className="contact-email" href="mailto:imasase176@gmail.com">imasase176@gmail.com <ArrowUpRight size={22} /></a>
            <div className="social-links">
              <a href="https://github.com/imasaseadheji-collab" target="_blank" rel="noreferrer"><Github size={17} /> GitHub</a>
              <a href="https://www.linkedin.com/in/imasase-adheji-09963b423" target="_blank" rel="noreferrer"><Linkedin size={17} /> LinkedIn</a>
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <span>© 2026 Imasase Adheji</span>
      </footer>
    </div>
  );
}
