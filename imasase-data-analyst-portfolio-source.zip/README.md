# Imasase Adheji — Data Analyst Portfolio

A responsive data analyst portfolio built with React, TypeScript, Tailwind CSS, and Vite.

## Featured project: Olist E-Commerce Operations Analysis

A practical analysis of a 10,000-order e-commerce dataset using **Excel, SQL, and Power BI**.

The case study investigates:

- Overall order volume and paid order value
- Late-delivery rate and late-order volume by state
- Average delivery time
- Customer review scores for late versus on-time deliveries
- Data completeness, uniqueness, and reporting readiness

### Key findings

- **RJ** recorded the largest absolute late-delivery volume with **332 late orders**.
- **CE** had the highest late-delivery rate among states with at least 100 delivered orders at **25.4%**.
- Late deliveries were associated with a lower average review score than on-time deliveries.
- The dataset contained **10,000 unique orders**, no duplicate order IDs, 85 missing reviews, and one missing delivery-day value.

### Tools used

- **Excel:** PivotTables, data checks, exploratory analysis, and conditional formatting
- **SQL:** repeatable KPI queries, state-level analysis, data-quality checks, and multi-table joins
- **Power BI:** DAX measures, interactive dashboard design, KPI cards, charts, tables, and report storytelling

## Portfolio features

- Editorial-style responsive layout
- Featured Olist case-study section
- Four-dashboard screenshot gallery
- Tool and workflow overview
- GitHub, LinkedIn, and email contact links
- Mobile navigation and responsive layouts

## Local development

```bash
pnpm install
pnpm dev
```

The site runs locally at `http://localhost:3000`.

## Production build

```bash
pnpm check
pnpm build
```

## Contact

- **Email:** imasase176@gmail.com
- **GitHub:** https://github.com/imasaseadheji-collab
- **LinkedIn:** https://www.linkedin.com/in/imasase-adheji-09963b423
